$(document).ready(function(){

    // Calculating Item Total Price
    $('[name="quantity[]"], [name="unit_price[]"]').on('input, change', function(){
        var qty = $(this).closest('.list-group-item').find('[name="quantity[]"]').val()
        var price = $(this).closest('.list-group-item').find('[name="unit_price[]"]').val()
        qty = qty > 0 ? qty : 0 ;
        price = price > 0 ? price : 0 ;
        var total = qty * price;
        $(this).closest('.list-group-item').find('[name="item_total[]"]').val(total)
        sub_total()
    })

    // Calculating Sub Total
    function sub_total(){
        var sub_total = 0
        $('[name="item_total[]"]').each(function(){
            sub_total += parseFloat($(this).val())
        })
        $('#sub_total').text(sub_total.toFixed(3))
        calc_total()

    }

    $('[name="quantity[]"]').trigger('change')

    // calculating discount amount from percentage
    $('#disc_perc').on('change', function(){
        var perc = $(this).val()
            perc = perc > 0 ? perc : 0;

        var sub_total =  $('#sub_total').text()
        
        var disc = parseFloat(perc / 100) * parseFloat(sub_total) ;
        $('#disc_amount').text(disc.toFixed(3))
        calc_total()
    })
    // calculating discount amount from percentage
    $('#tax_perc').on('change', function(){
        var perc = $(this).val()
            perc = perc > 0 ? perc : 0;

        var sub_total =  $('#sub_total').text()
        
        var tax = parseFloat(perc / 100) * parseFloat(sub_total) ;
        $('#tax_amount').text(tax.toFixed(3))
        calc_total()
       
    })

    // calculate Grand Total
    function calc_total(){
        var sub_total =  $('#sub_total').text()
        var disc =  $('#disc_amount').text()
        var tax =  $('#tax_amount').text()

        var total = (parseFloat(sub_total) - parseFloat(disc)) + parseFloat(tax)
        $('#total').text(total.toFixed(3))
    }
})